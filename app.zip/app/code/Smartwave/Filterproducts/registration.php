<?php
/**
* Copyright © 2016 SW-THEMES. All rights reserved.
*/
\Magento\Framework\Component\ComponentRegistrar::register(
\Magento\Framework\Component\ComponentRegistrar::MODULE,
'Smartwave_Filterproducts',
__DIR__
);
